package com.projet.tp.service;

public interface SoufianeService {
}
