package com.projet.tp.service;


import com.projet.tp.dao.*;
import com.projet.tp.entity.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class HamzaServiceImpl implements HamzaService {

    private ProductRep productRep;
    @Autowired
    public HamzaServiceImpl(ProductRep productRep)
    {
        this.productRep = productRep;
    }

    @Override
    public List<Product> findAll() {
        List<Product> produits= productRep.findAll();
        System.out.println(produits.get(0).getComposants());
        return productRep.findAll();
    }

    @Override
    public Product findone(int id) {
        Optional<Product> result=productRep.findById(id);
        Product produit=null;
        if(result.isPresent())
            {
                produit=result.get();
            }
        else {
            throw new RuntimeException("le produit "+id +" n'existe pas");
        }
        return produit;
    }

    @Override
    public void deleteById(int id_produit) {
        productRep.deleteById(id_produit);
    }

    @Override
    public void save(Product produit) {
        System.out.println("haha");
        productRep.save(produit);
    }


}
