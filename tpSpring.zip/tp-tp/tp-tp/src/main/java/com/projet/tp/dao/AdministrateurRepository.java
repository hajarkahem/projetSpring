package com.projet.tp.dao;

import com.projet.tp.entity.Administarteur;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdministrateurRepository extends JpaRepository<Administarteur, Integer> {
}
