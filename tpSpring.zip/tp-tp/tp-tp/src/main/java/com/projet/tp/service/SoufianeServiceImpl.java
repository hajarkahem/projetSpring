package com.projet.tp.service;


import org.springframework.stereotype.Service;

@Service

public class SoufianeServiceImpl implements SoufianeService {
}
