package com.projet.tp.entity;

public class Type_produit {
}
