package com.projet.tp.dao;

import com.projet.tp.entity.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRep extends JpaRepository<Product, Integer> {
}
