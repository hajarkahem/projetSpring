package com.projet.tp;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TpApplicationTests {

	@Test
	void contextLoads() {
	}

}
