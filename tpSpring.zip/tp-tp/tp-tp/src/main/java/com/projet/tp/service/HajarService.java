package com.projet.tp.service;

public interface HajarService {
}
